//
//  W02_MobCompApp.swift
//  W02-MobComp
//
//  Created by student on 18/09/25.
//

import SwiftUI

@main
struct W02_MobCompApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
