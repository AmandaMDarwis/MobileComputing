//
//  ContentView.swift
//  W02-MobComp
//
//  Created by student on 18/09/25.
//

import SwiftUI

struct ContentView: View {
    @State private var isItOn:Bool = false
    @State private var volume : Double = 0.5
    @State private var name : String = ""
    
    
    @State private var point = 80
    
    
    private func progressCard(score : Int) ->
    some View{
        VStack(){
            Text("Currewnt score").font(.headline)
            ProgressView(value:Double(score), total:100)
            Text("\(score)/100").foregroundStyle(.secondary)
        }}
    
    private func actionButton(_ title: String, action: @escaping() -> Void) //underscore : variabelnya cuma 1
    ->
    some View{
        Button(title, action: action)
            .padding(.horizontal, 16)
            .padding(.vertical, 10)
            .foregroundColor(.white)
            .background(Color.blue)
            .cornerRadius(10)
        
    }
    
    
    let fruits = ["Apple", "Orange", "Banana", "Apple", "Orange", "Banana", "Apple", "Orange", "Banana", "Apple", "Orange", "Banana", "Apple", "Orange", "Banana", "Apple", "Orange", "Banana", "Apple", "Orange", "Banana", "Apple", "Orange", "Banana", "Apple", "Orange", "Banana", "Apple", "Orange", "Banana"]
    
    var body: some View {
        //container -> bisa ada banyak component
        //        VStack(
        //               alignment: .center, //trailing = rata kanan, leading = rata kiri, center tengah
        //               spacing: 8
        //           ) {
        ////               ForEach(
        ////                1...10, //1 sampe 10 kalo 1..<10 → 1 sampe 9
        ////                   id: \.self // id = i di for i biasa
        ////               ) {
        ////                   Text("Hello World! \($0)") // $0 itu indexnya
        ////               }
        //               Spacer() // kasih jarak, menuhin layar/container
        //               Text("Amanda M. Darwis")
        //               Spacer()
        //               Text("Surabaya")
        //               Spacer()
        //               Text("Cete")
        //               Spacer()
        //
        //           }
        VStack{
            //            RoundedRectangle(cornerRadius: 20)
            //                .fill(.pink)
            //                .frame(width: 200, height: 125)
            //
            //            Text("Hello World!")
            //                .foregroundColor(.white)
            //                .font(.headline)
            //
            //            Circle()
            //                .frame(width: 50, height: 50)
            //                .opacity(0.2)
            
            
            // CLASS EXERCISE
            //            ZStack{
            //                RoundedRectangle(cornerRadius: 20)
            //                    .fill(.teal)
            //                    .frame(width: 200, height: 125)
            //
            //                HStack{
            //                    Text("Amanda").font(.title2)
            //                        .fontWeight(.semibold)
            //                        .padding(.bottom, 90)
            //                        .padding(.trailing, 30)
            //                    VStack{
            //                        Text("🐶").font(.system(size: 30, weight: .bold))
            //                        Text("🍌 🥭")
            //                    }.padding(.top, 40)
            //                }
            //            }
            //
            
            
            
            //            ZStack{
            //                RoundedRectangle(cornerRadius: 20)
            //                    .fill(.teal)
            //                    .frame(maxWidth: .infinity, alignment: .leading)
            //                    .background(.red).padding(10).background(Color.blue).cornerRadius(10)
            //                Spacer()
            //
            //
            //                    Text("Amanda")
            //                        .padding(.top, 90)
            //                        .background(Color.red)
            //
            //            }
            
            
            
            //SHADOWWWWW
            //            Text("Shadow Example")
            //                .padding()
            //                .background(Color.blue)
            //                .cornerRadius(10)
            //                .shadow(color: .gray, radius: 5, x:-2, y:2).opacity(0.8)
//            
//            
//            Button("Tekan Saya~"){
//                print("Saya di tekan")
//            }
//            .foregroundColor(Color.white)
//            .fontWeight(.bold)
//            .frame(maxWidth: .infinity, maxHeight: 50)
//            .background(.red)
//            .cornerRadius(30)
//            .shadow(color: .gray, radius: 5, x:2, y:2)
//            
//            Button("Login"){
//                print("Saya tertekan")
//            }
//            .foregroundColor(Color.white)
//            .fontWeight(.bold)
//            .frame(maxWidth: .infinity, maxHeight: 50)
//            .background(.blue)
//            .cornerRadius(30)
//            .shadow(color: .gray, radius: 5, x:2, y:2)
//            
//            Button("Sign Up"){
//                print("oHNOOO")
//            }
//            .padding(.horizontal, 150)
//            .padding(.vertical, 15)
//            .background(.white)
//            .overlay(RoundedRectangle(cornerRadius: 30)
//                .stroke(.blue, lineWidth: 2)).foregroundColor(.blue)
//            
//            Button("Default Button Apple"){
//                
//            } .buttonStyle(.bordered).tint(.purple).cornerRadius(30)
//            
//            
//            VStack {
//                Image(systemName: "figure.fall").foregroundColor(.red).font(.system(size: 100)).symbolRenderingMode(.multicolor)
//                
//                
//                                Toggle("Enable notifications", isOn: $isItOn).padding() //isOn = binding variabel toggle
//                                Text(isItOn ? "Hore" : "Yahh")
//                
//                
//                                Slider(value: $volume, in: 0...1)
//                                Text("Volume sekarang : \(volume)%")
//                
//                                TextField("Namamu Siapa", text: $name).textFieldStyle(.roundedBorder).padding()
//                                //                if(name == ""){
//                                //
//                                //                }else{
//                                //                    Text("Hello \(name)")
//                                //                }
//                                // atau
//                                Text(name == "" ? "hai" : "Hello \(name)")
//                
//                
//                
//                                HStack{
//                                    actionButton("add 10"){
//                                        point+=10
//                                    }
//                
//                                    actionButton("Reset"){
//                                        point = 0
//                                    }
//                                }
//                
//                
//           
//                
//                
//                
//            }
//            .padding()
            //        .background(.blue.opacity(0.2)) // sequential, kalo paddingnya setelah jadi gaada padding dalam bg nya
            //        .cornerRadius(20)
        }
        List(fruits, id:\.self){fruit in
            HStack{
                Text(fruit)
                Spacer()
                Text("u u a a")
            }}
        
    }
  
}
#Preview {
    ContentView()
}
