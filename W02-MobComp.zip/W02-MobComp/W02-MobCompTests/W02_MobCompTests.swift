//
//  W02_MobCompTests.swift
//  W02-MobCompTests
//
//  Created by student on 18/09/25.
//

import Testing
@testable import W02_MobComp

struct W02_MobCompTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
