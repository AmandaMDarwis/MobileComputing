//
//  W04_MobCompTests.swift
//  W04-MobCompTests
//
//  Created by student on 02/10/25.
//

import Testing
@testable import W04_MobComp

struct W04_MobCompTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
