//
//  ContentView.swift
//  W04-MobComp
//
//  Created by student on 02/10/25.
//

import SwiftUI

struct Movies: Identifiable {
    var id = UUID()
    var title: String
    var genre: String
    var posterUrl: String
    var est: String
    var detail: String
}
struct ContentView: View {
    let movies: [Movies] = [
        Movies(title: "The Devil Wears Prada", genre: "Drama", posterUrl: "https://upload.wikimedia.org/wikipedia/en/e/e7/The_Devil_Wears_Prada_main_onesheet.jpg", est: "2006", detail: "With an aspiration to become a journalist, Andy, a young graduate, travels to New York. She starts working as an assistant to one of the city's biggest magazine editors, the cynical Miranda Priestly."),
           Movies(title: "Titanic", genre: "Drama", posterUrl: "https://m.media-amazon.com/images/I/811lT7khIrL._UF894,1000_QL80_.jpg", est: "1997", detail: "Rose, who is being forced to marry a wealthy man, falls in love with Jack, a talented artist, aboard the unsinkable Titanic. Unfortunately, the ship hits an iceberg, endangering their lives."),
           Movies(title: "Pengabdi Setan", genre: "Horror", posterUrl: "https://upload.wikimedia.org/wikipedia/id/e/e1/Pengabdi_Setan_poster.jpg", est: "2017", detail: "After dying from a strange illness that she suffered for three years, a mother returned home to pick up her children."),
           Movies(title: "Smurfs", genre: "Cartoon", posterUrl: "https://upload.wikimedia.org/wikipedia/id/1/11/TheSmurfs2011Poster.jpg", est: "2011", detail: "When evil wizards Razamel and Gargamel take Papa Smurf, the Smurfs embark on a mission to the real world to save him. With help from some new friends, they must discover what defines their destiny to save the universe."),
           Movies(title: "Avatar", genre: "Sci-fi", posterUrl: "https://upload.wikimedia.org/wikipedia/id/b/b0/Avatar-Teaser-Poster.jpg", est: "2009", detail: "Jake, a paraplegic marine, replaces his brother on the Na'vi-inhabited Pandora for a corporate mission. He is accepted by the natives as one of their own, but he must decide where his loyalties lie."),
           Movies(title: "The Shallows", genre: "Thriller", posterUrl: "https://m.media-amazon.com/images/M/MV5BMjA1MTA4MzU4Ml5BMl5BanBnXkFtZTgwNjUxNjczODE@._V1_.jpg", est: "2016", detail: "Nancy travels to a secluded beach following the death of her mother. While surfing, she gets attacked by a great white shark, which leaves her stranded on a rock 200 yards from the shore.")
       ]

    @State private var searchText = ""
      
	var filteredMovies: [Movies] {
		  if searchText.isEmpty {
			  return movies
		  } else {
			  return movies.filter { $0.title.lowercased().contains(searchText.lowercased()) }
		  }
	  }
      
    
    var body: some View {
        NavigationStack{
            VStack{
                NavigationStack {
                    ScrollView {
                        HStack {
                            Image(systemName: "magnifyingglass")
                                .foregroundColor(.gray)
                            TextField("Search", text: $searchText)
                        } .padding()            .background(Color(.systemGray6))
                            .cornerRadius(12)
                            .padding(.horizontal)

                        LazyVGrid(columns: [GridItem(.adaptive(minimum: 150))], spacing: 20) {
                            ForEach(filteredMovies) { movie in
                                NavigationLink(destination: MovieDetailView(movie: movie)) {
                                    MovieCard(movie: movie)
                                }
                            }
                        }
                        .padding()
                    }
                    
                }
                
            }
            .navigationTitle(Text("UCFlix"))
			
        }
        
    }
}



#Preview {
	ContentView()
}
