//
//  SplashScreen.swift
//  W04-MobComp
//
//  Created by student on 02/10/25.
//

import SwiftUI

struct SplashScreen: View {
    @State private var isActive = false
    @State private var opacity = 0.0
    
    var body: some View {
        if isActive {
//            ContentView()
        } else {
            VStack {
                Image(systemName: "film")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 120, height: 120)
                    .foregroundColor(.white) 
                    .opacity(opacity)
                    .onAppear {
                        withAnimation(.easeIn(duration: 1.5)) {
                            opacity = 1.0
                        }
                        // After delay, switch to main content
                        DispatchQueue.main.asyncAfter(deadline: .now() + 2.5) {
                            withAnimation {
                                isActive = true
                            }
                        }
                    }
                Text("UCFlix")
                    .font(.largeTitle)
                    .foregroundColor(.white)
                    .fontWeight(.bold)
                    .opacity(opacity)
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(LinearGradient(colors: [Color.red, Color.black], startPoint: .top, endPoint: .bottom))
            .ignoresSafeArea()
        }
    }
}
