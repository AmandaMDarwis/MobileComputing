//
//  SplashScreen.swift
//  W04-MobComp
//
//  Created by student on 02/10/25.
//

import SwiftUI

struct SplashScreen: View {
    @State private var opacity = 0.0
	@Binding var isFirstLaunch: Bool
    
    var body: some View {
            VStack {
                Image(systemName: "film")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 120, height: 120)
                    .foregroundColor(.white) 
                    .opacity(opacity)
					.onAppear() {
						withAnimation(.easeIn(duration: 1.5)) {
							opacity = 1.0
						}
					}
                    
                Text("UCFlix")
                    .font(.largeTitle)
                    .foregroundColor(.white)
                    .fontWeight(.bold)
                    .opacity(opacity)
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(LinearGradient(colors: [Color.red, Color.black], startPoint: .top, endPoint: .bottom))
            .ignoresSafeArea()
			.onAppear {
				// After delay, switch to main content
				DispatchQueue.main.asyncAfter(deadline: .now() + 2.5) {
					withAnimation {
						self.isFirstLaunch = false
					}
				}
			}
    }
}

#Preview {
	SplashScreen(isFirstLaunch: .constant(true))
}
