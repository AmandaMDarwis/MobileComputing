//
//  MovieCard.swift
//  W04-MobComp
//
//  Created by student on 02/10/25.
//

import SwiftUI


struct MovieCard: View {
    @State var movie: Movies
    
    var body: some View {
        VStack {
            AsyncImage(url: URL(string: movie.posterUrl)) { image in
                image.resizable()
                     .scaledToFill()
                     .frame(height: 200)
                     .cornerRadius(10)
                     .clipped()
            } placeholder: {
                ProgressView()
            }
            
            Text(movie.title)
                .font(.headline)
                .lineLimit(1)
                .padding(.vertical, 5)
                .padding(.horizontal)
            
            HStack{
                Text(movie.genre)
                    .foregroundColor(.secondary)
                Text ("|").foregroundColor(.secondary)
                Text(movie.est)
                    .foregroundColor(.secondary)
            }
         

        }.padding(.bottom, 15)
        .frame(width: 170)
        .background(Color.white)
        .cornerRadius(10)
        .shadow(radius: 10)
        .id(movie.id)
    }
}
