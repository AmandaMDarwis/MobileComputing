//
//  MovieDetail.swift
//  W04-MobComp
//
//  Created by student on 02/10/25.
//

import SwiftUI
struct MovieDetailView: View {
    @State var movie: Movies
    
    var body: some View {
        ScrollView {
            VStack {
                AsyncImage(url: URL(string: movie.posterUrl)) { image in
                    image.resizable()
                         .scaledToFit()
                         .frame(height: 300)
                         .cornerRadius(15)
                         .clipped()
                } placeholder: {
                    ProgressView()
                }
                
                Text(movie.title)
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .padding(.top)
                
                Text(movie.genre)
                    .font(.title2)
                    .foregroundColor(.secondary)
                    .padding(.top, 5)
                
                Text("Established at \(movie.est)")
                    .font(.title2)
                    .foregroundColor(.secondary)
                
                Text(movie.detail)
                    .foregroundColor(.secondary)
                    .multilineTextAlignment(.center)
                    .padding(.top, 5)
            }
            .padding()
        }
        .navigationTitle(movie.title)
        .navigationBarTitleDisplayMode(.inline)
    }
}
