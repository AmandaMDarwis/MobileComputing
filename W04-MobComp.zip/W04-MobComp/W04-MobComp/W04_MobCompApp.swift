//
//  W04_MobCompApp.swift
//  W04-MobComp
//
//  Created by student on 02/10/25.
//

import SwiftUI

@main
struct W04_MobCompApp: App {
	@State var isFirstLaunch: Bool = true
	
    var body: some Scene {
        WindowGroup {
			if isFirstLaunch {
				SplashScreen(isFirstLaunch: $isFirstLaunch)
			} else {
				ContentView()
			}
        }
    }
}
