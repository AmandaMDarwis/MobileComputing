//
//  ContentView.swift
//  W01-Mobcomp
//
//  Created by student on 11/09/25.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        
        VStack {
//            Image(systemName: "globe")
//                .imageScale(.large)
//                .foregroundStyle(.tint)
            Text("Hello, world!").font(.largeTitle).fontWeight(.bold).padding(.horizontal)
            Text("Declarative UI | Live Preview | SwiftUI Cool").multilineTextAlignment(.center).padding().font(.headline).fontWeight(.semibold).foregroundColor(.blue)
                .background(.ultraThinMaterial).clipShape(RoundedRectangle(cornerRadius: 16))
            
            Image(systemName:"sparkles")
                .imageScale(.large)
//                .foregroundColor(.yellow)
                .foregroundStyle(LinearGradient(colors: [.blue, .red], startPoint: UnitPoint.topLeading, endPoint: .bottomTrailing))
                .font(.system(size: 100))
                .padding().overlay(content: {
                    Circle()
                    .strokeBorder(.gray.opacity(0.3),lineWidth: 2)                })
            
        }
        
        HStack(spacing: 15){
            HStack(alignment:.center){
                Text("☺️")
                Text("☺️")
                Text("☺️")
            }
            VStack(){
                Text("💕")
                Text("💕")
                Text("💕")
            }
            HStack(){
                Text("👀")
                Text("👀")
                Text("👀")
            }
        }
        
        .padding()
    }
//    func getRandomColor() -> Color {
//        Color(
//            red: .random(in: 0...1),
//            green: .random(in: 0...1),
//            blue: .random(in: 0...1)
//        )
//    }
    var angka1: Int = 1 // <-bisa berubah
    let angka2: Int = 2 // <-gabisa berubah
    let name="Alice"
    var age = 20
    func greet() {
        print("Hello, \(name), \(age)")
    }
    
}

#Preview {
    ContentView()
}
