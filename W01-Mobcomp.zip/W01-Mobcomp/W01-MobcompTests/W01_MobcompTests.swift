//
//  W01_MobcompTests.swift
//  W01-MobcompTests
//
//  Created by student on 11/09/25.
//

import Testing
@testable import W01_Mobcomp

struct W01_MobcompTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
