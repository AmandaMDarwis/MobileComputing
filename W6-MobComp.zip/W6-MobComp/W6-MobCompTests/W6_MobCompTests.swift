//
//  W6_MobCompTests.swift
//  W6-MobCompTests
//
//  Created by student on 16/10/25.
//

import Testing
@testable import W6_MobComp

struct W6_MobCompTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
