//
//  W6_MobCompApp.swift
//  W6-MobComp
//
//  Created by student on 16/10/25.
//

import SwiftUI
import CoreData

@main
struct W6_MobCompApp: App {
    let persistence = PersistenceController.shared
    var body: some Scene {
        WindowGroup {
//            ContentView()
            let vm = CoreDataStudentViewModel(context: persistence.container.viewContext)
            CoreDataStudentsView(vm:vm)
        }
    }
}
