//
//  ContentView.swift
//  W6-MobComp
//
//  Created by student on 16/10/25.
//

import SwiftUI
//CONTOH ENUM BUAT GAME, ENUM BISA DILUAR STRUCT
enum LoadingState{
    case idle
    case loading
    case success(data:String)
    case error(message: String)
}
struct ContentView: View {
    //panggil enum yg diluar struct
    @State private var state: LoadingState = .idle
    
    //Array
    @State private var fruits : [String] = ["Apple", "Pear", "Durian"]
    
    //Dictionary --> dia nyimpannya pasangan, sedangkan kalau array sendiri"
    @State private var scores : [String:Int] = [
        "Alice":90,
        "Martini":80,
        "Sutris":20
    ]
    @State private var newStudent : String = ""
    
    //CLASS
    @Observable
    class Counter{
        var count: Int = 0
        func increment(){ count+=1 }
        func decrement(){ count-=1 }
    }
    
    @State private var counterA = Counter()
    @State private var counterB: Counter? = nil
    //optional
    
    // SET
    @State private var programmingLanguage: Set<String> = ["Swift", "Phyton", "JavaScript"]
    @State private var newLang: String = ""
    
    //Tuple -> cenderung digunakan untuk menampung tipe variabel yabg sama, bisa menerima duplicate, urutan tidak dapat berubah, biasa digunakan untuk data yang kecil, bentuk umumnya let bukan var, biasanya difungsikan untuk membawa sepaket informasi, tuple lebih ringan daripada dict
    @State private var point: (x:Int, y:Int) = (x:0, y:0)
    
    
    //Enum
    enum Grade: String, CaseIterable{
        case A, B, C, D, E
        
        var color:Color{
            switch self{
            case .A: return .green
            case .B: return .yellow
            case .C: return .orange
            case .D: return .red
            case .E: return .blue
            }
        }
    }
    
//    enum APIResponse {
//        case success(message: String)
//        case failure(error: Int, reason: String)
//    }
//    let response1 = APIResponse.success(message: "Data Loaded!")

    @State private var grade:Grade = .A
    
   
    
    var body: some View {
        VStack{
//            Text("Array of fruits").font(.largeTitle)
//                        
//            HStack{
//                ForEach(fruits, id:\.self){
//                    fruit in
//                    Text(fruit)
//                        .padding(10)
//                        .background(Color.orange.opacity(0.3))
//                        .clipShape(Capsule())
//                }
//            }
//            
//            HStack{
//                Button("Add Fruit"){
//                    fruits.append("Banana")
//                }
//                .buttonStyle(.borderedProminent)
//
//                Button("Remove Last"){
//                    if !fruits.isEmpty{
//                        fruits.removeLast()
//                    }
//                }
//            }
            
//            
//            Text("Dictionary Explanation")
//                .font(.largeTitle)
//            VStack{
//                //$0 = item pertama di index pertama dari key (sisi kiri dari dictionary)
//                ForEach(scores.sorted(by: {$0.key < $1.key}), id:\.key){
//                    name, score in
//                    HStack{
//                        Text(name)
//                        Spacer()
//                        Text("\(score)").bold(true)
//                    }
//                }
//            }
//            .padding()
//            
//            //di dictionary gabisa isi cuma salah satu atributnya, harus isi semua
//            HStack{
//                Button("Increase Butris' Score !"){
//                    scores["Butris", default: 0] += 5
//                }.buttonStyle(.borderedProminent)
//                
//                //Buat button untuk delete semua value di dictionarynya
//                Button("Delete All"){
//                    scores.removeAll()
//                }.buttonStyle(.borderedProminent)
//               
//            }
//            VStack{
//                TextField("New Student Name", text: $newStudent).textFieldStyle(.roundedBorder)
//                
//                Button("Add new student"){
//                    if !newStudent.isEmpty {
//                        scores[newStudent] = 5
//                        newStudent = ""
//                    }
//                    
//                }.buttonStyle(.borderedProminent)
//            }.padding()
//
            
            
            //CLASSSSSSSSSSS
//            Text("Counter A : \(counterA.count)")
//            Text("Counter B : \(counterB?.count ?? 0)") //kalo tipeny optional harus dikasih opsi
//                .foregroundStyle(counterB == nil ? .red : .primary)
//            
//            HStack{
//                Button("+"){ counterA.increment() }.buttonStyle(.borderedProminent)
//                Button("-"){ counterA.decrement() }.buttonStyle(.borderedProminent)
//                
//                
//                Button(counterB == nil ? "Clone A to b" : "Unlink B"){
//                    if counterB == nil{
//                        counterB = counterA
//                    } else{
//                        counterB = nil
//                    }
//                }.buttonStyle(BorderedButtonStyle())
//                
//                Button("+"){ counterB?.increment() }
//            }
            
//            HStack{
//                Button("+"){ counterB.increment() }.buttonStyle(.borderedProminent)
//                Button("-"){ counterB.decrement() }.buttonStyle(.borderedProminent)
//            }
            
            
                    
            //SETTTT -> aksesnya tidak by index, ga punya urutan. dia gabisa duplicate. Biasanya buat kategori"
//            Text("Ini adalah set").font(.largeTitle)
//            HStack{
//                ForEach(Array(programmingLanguage), id:\.self){lang in
//                    Text(lang)
//                        .padding(5)
//                        .background(.green)
//                        .clipShape(Capsule())
//                }
//            }
//            
//            HStack{
//                TextField("Enter new language", text: $newLang)
//                    .textFieldStyle(RoundedBorderTextFieldStyle())
//                    .frame(width:200)
//                Button("Add"){
//                    if !newLang.isEmpty{
//                        programmingLanguage.insert(newLang)
//                        newLang = ""
//                    }
//                }
//            }
          
            
            //TUPLEEEEE
//            Text("Ini adalah tuple").font(.largeTitle)
//            
//            Text("Nilai sekarang XY : \(point.x), \(point.y)")
//            
//            HStack{
//                Button("Kanan 10 langkah"){
//                    point.x += 10
//                }.buttonStyle(.borderedProminent)
//                Button("Kebawah 10 langkah"){
//                    point.y -= 10
//                }.buttonStyle(.borderedProminent)
//            }
            
            
            //ENUM
//            Picker("Select grade", selection: $grade){
//                ForEach(Grade.allCases, id:\.self){
//                    g in Text(g.rawValue)
//                }
//            }.padding()
//            .pickerStyle(.segmented)
//            
//            Text("Your Grade: \(grade.rawValue)")
//                .font(Font.largeTitle.bold())
//                .foregroundColor(grade.color)
//            
//            
            
            
            //enum game
            Group{
                switch state{
                case .idle:
                    Text("Tap to start loading")
                case .loading:
                    ProgressView("Loading...")
                case .success(let data):
                    Text("Loaded: \(data)")
                        .foregroundColor(Color.green)
                case .error(message: let msg):
                    Text("eRROR: \(msg)")
                        .foregroundColor(Color.red)
                }
            }
            HStack{
                Button("Start"){state = .loading}
                Button("Success"){state = .success(data: "KTP mu telah diupload untuk pinjol")}
            }
            
            
            
            
        }
    }
}

#Preview {
    ContentView()
}
