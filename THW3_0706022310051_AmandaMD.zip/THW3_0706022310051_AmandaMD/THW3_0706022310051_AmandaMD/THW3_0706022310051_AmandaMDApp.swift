//
//  THW3_0706022310051_AmandaMDApp.swift
//  THW3_0706022310051_AmandaMD
//

import SwiftUI

@main
struct THW3_0706022310051_AmandaMDApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
