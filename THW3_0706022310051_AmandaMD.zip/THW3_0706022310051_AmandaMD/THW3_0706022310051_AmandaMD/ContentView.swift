//
//  ContentView.swift
//  THW3_0706022310051_AmandaMD
//

import SwiftUI

struct ContentView: View {
    var body: some View {
		VStack(spacing: 20) {
					HStack {
						VStack(alignment: .leading, spacing: 4) {
							Text("Good Morning,")
								.font(.headline)
								.foregroundColor(.gray)
							Text("Amanda")
								.font(.largeTitle)
								.bold()
						}
						Spacer()
						Image(systemName: "person.crop.circle")
							.resizable()
							.frame(width: 50, height: 50)
					}
					.padding(.horizontal)
					
					HStack {
						Image(systemName: "magnifyingglass")
							.foregroundColor(.gray)
						TextField("Search", text: .constant(""))
					}
					.padding()
					.background(Color(.systemGray6))
					.cornerRadius(12)
					.padding(.horizontal)
					
					VStack(alignment: .center, spacing: 16) {
						Text("Today's Goal")
							.font(.title).fontWeight(.bold)
							.foregroundColor(.white)
						
						HStack(spacing: 16) {
							GoalCardView(icon: "figure.run", value: "4 Miles", subtitle: "@Thames Route", gradient: Gradient(colors: [.red, .pink]))
							GoalCardView(icon: "figure.rower", value: "2 Miles", subtitle: "@River Lea", gradient: Gradient(colors: [.pink, .purple]))
						}
					}
					.padding(15)
					.padding(.vertical, 15)
					.frame(maxWidth: .infinity)
					.background(
						LinearGradient(gradient: Gradient(colors: [.teal, .pink]),
									   startPoint: .topLeading,
									   endPoint: .bottomTrailing)
					)
					.cornerRadius(24)
					.padding()
					
					LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 16) {
						StatCardView(icon: "heart.fill", iconColor: .purple, value: "68 Bpm")
						StatCardView(icon: "flame.fill", iconColor: .orange, value: "0 Kcal")
						StatCardView(icon: "scalemass.fill", iconColor: .green, value: "73 Kg")
						StatCardView(icon: "moon.zzz.fill", iconColor: .blue, value: "6.2 Hr")
					}
					.padding(.horizontal)
					
					Spacer()
					
				TabView{
					HomeView()
						.tabItem{
							Label("Home", systemImage: "house.fill")
						}

					MapView()
						.tabItem{
							Label("Map", systemImage: "mappin.and.ellipse")
						}
					GraphView()
						.tabItem{
							Label("Statistics", systemImage:"chart.bar.xaxis.ascending")
						}
					SettingsView()
						.tabItem{
							Label("Settings", systemImage:"gear")
						}
				}.tint(.blue)

		}.padding(.horizontal, 10)
    }
}

struct HomeView:View {
	var body: some View {
		VStack{
			
		}
	}
}

struct MapView:View {
	var body: some View {
		VStack{
		
		}
	}
}

struct GraphView:View {
	var body: some View {
		VStack{
			
		}
	}
}

struct SettingsView:View {
	var body: some View {
		VStack{
			
		}
	}
}

struct GoalCardView: View {
	var icon: String
	var value: String
	var subtitle: String
	var gradient: Gradient
	
	var body: some View {
		VStack(spacing: 8) {
			Image(systemName: icon)
				.font(.largeTitle)
				.foregroundColor(.white)
			Text(value)
				.font(.title3)
				.bold()
				.foregroundColor(.white)
			Text(subtitle)
				.font(.caption)
				.foregroundColor(.white.opacity(0.8))
		}
		.frame(maxWidth: .infinity, maxHeight: 300)
		.padding(20)
		.background(.opacity(0.2))
		.cornerRadius(20)
	}
}

struct StatCardView: View {
	var icon: String
	var iconColor: Color
	var value: String

	var body: some View {
		ZStack {
			RoundedRectangle(cornerRadius: 20)
				.fill(Color(.systemGray6))
				.frame(height: 100)

			VStack {
				HStack {
					Image(systemName: icon)
						.foregroundColor(iconColor)
						.font(.title3)
					Spacer()
				}
				Spacer()
				HStack {
					Spacer()
					Text(value)
						.font(.title2)
						.fontWeight(.semibold)
						.opacity(0.7)
				}
			}
			.padding(12)
		}
	}
}


#Preview {
    ContentView()
}
