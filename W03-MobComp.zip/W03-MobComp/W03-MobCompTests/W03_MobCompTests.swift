//
//  W03_MobCompTests.swift
//  W03-MobCompTests
//
//  Created by student on 25/09/25.
//

import Testing
@testable import W03_MobComp

struct W03_MobCompTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
