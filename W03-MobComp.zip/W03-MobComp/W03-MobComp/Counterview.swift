//
//  Counterview.swift
//  W03-MobComp
//
//  Created by student on 25/09/25.
//

import SwiftUI

struct Counterview: View {
    @Binding var count : Int
    //nilai valuenya bisa dipassing antar view, state gabisa
    var body: some View {
        //        Text("Hello, World!\(count)")
        VStack{
            Text("Child View (CounterView")
                .font(.headline)
            HStack{
                Button("-"){
                    count-=1
                }.buttonStyle(.bordered)
                Button("+"){
                    count+=1
                }.buttonStyle(.bordered)
            }
        }
        
        
        .padding()
        .background(.pink.opacity(0.8))
        .cornerRadius(10)
    }
}

