//
//  W03_MobCompApp.swift
//  W03-MobComp
//
//  Created by student on 25/09/25.
//

import SwiftUI

@main
struct W03_MobCompApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
