//
//  ContentView.swift
//  W03-MobComp
//
//  Created by student on 25/09/25.
//


// arsitektur biasanya kan mvc, ini MVVM -> Model view ViewModel -> controlller bisa masuk model/view
import SwiftUI
struct ContentView2: View {
    var body: some View {
        VStack{
            Text("View 2")
        }
        .padding()
        .background(Color.blue)
    }
}
struct ContentView: View {
    //struct immutable, gabisa dikasih value yang immutable juga
    //    @State private var number = 0
    //
    //    @State private var count = 0
    //    @State private var nama = ""
    
    @State private var totalCount = 0
    
    
    
    // @State property wrapper yang membantu untuk mutable variabel tersebut. kalo gaada statenya dia jadi var immutable. valuenya gabisa diubah jadi dirinya sendiri, ke bound dengan viewnya.
    // @State nyimpan variabel tersebut biar bisa berubah dan akan berdampak pada viewnya.
    // ketika value state berubah, swiftui aan generat ulang seluruh tampilannya
    // state eksklusif untuk parentnya gabisa dipake di view lain.
    
    
    
    var body: some View {
        VStack {
            //            ContentView2()
            //            Button("Tambah"){
            //                number+=1
            //            }
            //            Text("Hello World! \(number)")
            //            Text("Hitung : \(count)")
            //                .font(.largeTitle)
            //            Text("Nama: \(nama)")
            //
            //            TextField("Isi Nama", text: $nama)
            //                .textFieldStyle(RoundedBorderTextFieldStyle())
            //
            //            HStack{
            //                Button("-"){
            //                    count-=1
            //                }.font(.largeTitle.bold())
            //                Button("+"){
            //                    count+=1
            //                }.font(.largeTitle.bold())
            //            }
            
            
            
            
            
            //            VStack{
            //                Text("Parent View")
            //                    .font(.largeTitle)
            //                Text("Total Count: \(totalCount)")
            //                    .font(.title2)
            //                    .padding()
            //
            //                Counterview(count: $totalCount)
            //                Spacer()
            //            }
            //            .padding()
            //            .background(.green.opacity(0.6))
            
            
            //////////////////////////////////////////////////////////
            
            //
            //            TabView{
            //                HomeView()
            //                    .tabItem{
            //                        Label("Home", systemImage: "house.fill")
            //                    }
            //                    .badge(99)
            //
            //                SearchView()
            //                    .tabItem{
            //                        Label("Search", systemImage: "magnifyingglass")
            //                    }
            //                ProfileView()
            //                    .tabItem{
            //                        Label("Profile", systemImage:"person.fill")
            //                    }
            //                SettingView()
            //                    .tabItem{
            //                        Label("Profile", systemImage:"accessibility")
            //                    }
            //            }
            //            .tint(.blue)
            //
            //        }
            
            
            
            
            
            NavigationStack{
                VStack(spacing: 20){
                    Text("🏡 Home Screen")
                        .font(.largeTitle)
                    NavigationLink("Go to Details"){
                        DetailScreen()
                    }
                    NavigationLink("Show item"){
                        ItemScreen()
                    }
                }
            }
        }
    }
    
}
struct DetailScreen: View {
    var body: some View {
        VStack{
            Text("📑 Detail Screen")
                .font(.largeTitle)
            Text("You come from home screen!")
        }
        .navigationTitle("Detail")
            .navigationBarTitleDisplayMode(.inline)
    }
}

struct ItemScreen: View {
    let items = ["Tomato 🍅", "Banana 🍌", "Pineapple 🍍"]
    var body: some View{
        List(items, id: \.self){ item in  NavigationLink(destination: ItemDetailScreen(item:item)){
            Text(item)
            }
        }
        .navigationTitle("Items")
    }
}
struct ItemDetailScreen: View {
    let item: String
    var body: some View{
        
        VStack{
            Text("🍉 Welcome to Item Detail! 🫐")
                .font(.title)
            Text("You selected : \(item)")
                
        }
        .navigationTitle(item)
        .navigationBarTitleDisplayMode(.inline)
    }
}
struct HomeView:View {
    @State private var textku = ""
    var body: some View {
        Form{
            VStack{
                Text("🏡 Home")
                    .font(.largeTitle)
                TextField("Name : ", text: $textku)
                    .border(Color.gray)
            }
        }.padding()
            .background(.green.opacity(0.4))
       
    }
}

struct SearchView:View {
    var body: some View {
        VStack{
            Text("👀 Search")
                .font(.largeTitle)
        }
    }
}

struct ProfileView:View {
    var body: some View {
        VStack{
            Text("🙆🏻‍♀️ Profile")
                .font(.largeTitle)
        }
    }
}

struct SettingView:View {
    var body: some View {
        VStack{
            Text("⚙️ Settings")
                .font(.largeTitle)
        }
    }
}
    
#Preview {
    ContentView()
}
