//
//  ContentView.swift
//  W01-Class Practice
//
//  Created by student on 11/09/25.
//

import SwiftUI
// kalo mau declare variable mending buat struct baru

struct Student{
    var nama:String
    var year: Int
    func disply() ->String{
        "\(nama), \(year)"
    }
}

enum UserStatus{case offline, online, busy} //mirip sama class


struct ContentView: View {
//    let username = "Blabla"
//    let scores = [89,92,76]
//    let student = Student(nama:"Bibi", year:2)
//    let status: UserStatus = .online
//    
//    var badge: String{
//        scores.allSatisfy {$0 >= 85} ? "✅" : "❌"
//    }
    
    var body: some View {
//        VStack(spacing:10){
//            Text("Hello, \(username)").font(.title)
//            Text("Student: \(student.disply())")
//            Text("Status: \(status == .online ? "🟢 Online" : " Offline")") //kalo tnd tanya 1 dia true/false, kalo tanda tnya 2 brarti ada jawaban lain
//        }
//        
//        
//        
       //------------------------CLASS ASSIGNMENT----------------------------
        VStack {
            
            Image("profile").resizable()
                /*.frame(width: 200, height: 200, alignment:.topLeading)*/
                 .scaledToFit()
                 .clipShape(Circle())
                .font(.system(size: 100))
//                .overlay(content: {
//                   Circle()
//                })
                .foregroundStyle(.tint).padding()
                .padding(.bottom, 70)
                .padding(.top, 40)
            
            let name = "Amanda"
            Text("Hi, I'm \(name)").padding().font(.largeTitle).fontWeight(.bold).foregroundStyle(LinearGradient(colors: [.blue, .red], startPoint: UnitPoint.topLeading, endPoint: .bottomTrailing))
            
//                .background(.ultraThinMaterial).clipShape(RoundedRectangle(cornerRadius: 16))
            Text("My age is 19").padding().font(.title.italic()).fontWeight(.semibold).foregroundColor(.blue)
            Text("💙🥰🤯").padding().font(.title) .background(.ultraThinMaterial).clipShape(RoundedRectangle(cornerRadius: 15)).padding(.top,20)
        }
//        .padding()
        Spacer()
    }
}

#Preview {
    ContentView()
}

