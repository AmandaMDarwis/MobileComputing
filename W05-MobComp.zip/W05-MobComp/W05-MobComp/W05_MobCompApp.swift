//
//  W05_MobCompApp.swift
//  W05-MobComp
//
//  Created by student on 09/10/25.
//

import SwiftUI

@main
struct W05_MobCompApp: App {
    var body: some Scene {
        WindowGroup {
//            ContentView()
//            CounterHomeView()
//            TaskListView()
            MovieHomeView()
        }
    }
}
