//
//  Fruit.swift
//  W05-MobComp
//
//  Created by student on 09/10/25.
//
// model biasanya bentuk struct
import Foundation

struct Fruit: Identifiable, Codable, Hashable {
    let UUID: UUID  // Universal Unique ID
    let id: String //A001
    let name: String //apple
    let color: String //green
    // identifiable = who's who
    // codable = struct ini bisa komunikasi dengan file lain/API
    // Hashable = swift bisa melakukan komparasi/track codenya
    
//    ForEach(fruits, id: \.name)(fruit) in{
//        //untuk setiap fruit yang dipunya mereka punya identifier "\.id" itu boleh diganti sama atribut dari classnya misal diganti jadi name atau color
//        
//    }
}
