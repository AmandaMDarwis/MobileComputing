//
//  Task.swift
//  W05-MobComp
//
//  Created by student on 09/10/25.
//

import Foundation
//dimulai dari model, buat yang rapi, baru ngoding untuk function dkk (ViewModel)
//Model >> ViewModel (bergerak) >> View (bergerak)
import SwiftUI

struct Task: Identifiable,Codable, Hashable {
    var id = UUID() //kalo di declare "=UUID()" dia bakal random idnya
    var title: String
    var isCompleted: Bool = false
}

