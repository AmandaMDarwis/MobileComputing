//
//  ContentView.swift
//  W05-MobComp
//
//  Created by student on 09/10/25.
//

// Arsitektur -> Model - View - Viewmodel

import SwiftUI

struct CounterHomeView: View {
    @State private var vm = CounterVM()
    //vm : var yang isinya view model
    // view gaboleh menjalanlkan code yg kayak logic. misal penjumlahan, perkalian, dkk.
    // jadi smua proses itu di viewmodel, view cuma panggil
    var body: some View{
        NavigationStack{
            VStack(spacing:16){
                Text("Count : \(vm.count)")
                    .font(.largeTitle).bold()
                Text(vm.isEven ? "Even" : "Odd")
                    .foregroundStyle(.secondary)
                HStack(spacing: 20){
                    Button("+"){
                        vm.increment()
                    }.buttonStyle(.bordered)
                    Button("-"){
                        vm.decrement()
                    }.buttonStyle(.bordered)
                }
                
                Button("Reset"){
                    vm.reset()
                }.buttonStyle(.borderedProminent)
                
                NavigationLink("Mirror Screen") {
                    CounterMirrorView(vm: vm)
                    //vm yang ada di CounterMirrorView = yg diatas, soalny yang diatas itu di State. yg kiri punya countermirrorview, yg kanan yg punya counterhomeview
                }
                            }
        }
    }
}

struct CounterMirrorView: View {
    var vm: CounterVM
    var body: some View{
        VStack(spacing:16){
            Text("Mirror Count : \(vm.count)")
            Button("Add Here"){
                vm.increment()
            }
        }
        .font(.title2)
        .padding()
    }
}

#Preview {
//    ContentView()
    CounterHomeView()
}

