//
//  CounterVM.swift
//  W05-MobComp
//
//  Created by student on 09/10/25.
//

import Foundation
import SwiftUI

@Observable
// dibaca dan digunakan dimanapun dia dipanggil anggepannya kayak "public"
// ketika bikin sebuah passing class, kan biasany ga cuma ibject, mungkin ada increment dkk MAKANYA PAKE OBSERVABLE
final class CounterVM {
    var count: Int = 0
    
    var isEven: Bool {
        count % 2==0
    }
    
    func increment(){
        count+=1
    }
    func decrement()
    {
        count-=1
    }
    func reset(){
        count=0
    }
}
