//
//  W05_MobCompTests.swift
//  W05-MobCompTests
//
//  Created by student on 09/10/25.
//

import Testing
@testable import W05_MobComp

struct W05_MobCompTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
