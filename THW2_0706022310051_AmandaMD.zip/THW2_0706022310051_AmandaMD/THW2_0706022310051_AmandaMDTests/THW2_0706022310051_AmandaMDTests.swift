//
//  THW2_0706022310051_AmandaMDTests.swift
//  THW2_0706022310051_AmandaMDTests
//

import Testing
@testable import THW2_0706022310051_AmandaMD

struct THW2_0706022310051_AmandaMDTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
