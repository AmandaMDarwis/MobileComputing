//
//  THW2_0706022310051_AmandaMDApp.swift
//  THW2_0706022310051_AmandaMD
//
//  Created by Timothy on 21/09/25.
//

import SwiftUI

@main
struct THW2_0706022310051_AmandaMDApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
