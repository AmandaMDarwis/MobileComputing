//
//  ContentView.swift
//  THW2_0706022310051_AmandaMD
//

import SwiftUI

struct TodoItem: Identifiable {
    let id = UUID()
    var task: String
    var isCompleted: Bool
}

struct ContentView: View {
    @State private var newTask = ""
    @State private var todoItems: [TodoItem] = []
    @State var isDone: Int = 0
    @State var notDone: Int = 0
    
    var body: some View {
        VStack {
            Text("Welcome !")
                .font(.largeTitle).fontWeight(.bold)
                .foregroundStyle(LinearGradient(
                    colors: [.blue, .purple],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing)
                    )
               
            Text("Your To-Do List :")
                .font(.title2)
                .padding(.bottom, 30)
                .padding(.top, 10)
                // .font(.system(size: 34, weight: .bold, design: [.rounded))
            
            
            HStack(alignment: .center) {
//                Image(systemName: "icon")
//                                   .font(.title2)
//                                   .foregroundColor(.mint)
                               
               VStack(alignment: .center) {
                   Text("Finished")
                       .font(.system(.headline, design: .rounded))
                       .foregroundColor(.gray)
                   
                   Text("\(todoItems.filter { $0.isCompleted }.count)")
                       .font(.system(.title2, design: .rounded).bold())
                       .foregroundColor(.green)
               }.padding(.horizontal, 25)
                    .padding(.vertical)
                    .background(Color.green.opacity(0.2))
                    .cornerRadius(10)
                    .padding(.trailing, 20)
                    
                VStack(alignment: .center) {
                    Text("Unfinished")
                        .font(.system(.headline, design: .rounded))
                        .foregroundColor(.gray)
                    
                    Text("\(todoItems.filter { !$0.isCompleted }.count)")
                        .font(.system(.title2, design: .rounded).bold())
                        .foregroundColor(.red)
                }.padding()
                    .background(Color.red.opacity(0.2))
                    .cornerRadius(10)
            }
            HStack(){
                TextField("Enter your assignments", text: $newTask)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                Button(action: addTask) {
                    Image(systemName: "plus.circle.fill")
                        .foregroundColor(.blue)
                        .font(.largeTitle)
                        .imageScale(.large)
                }
            }
            
            Button(action: selectAllTasks) {
                Text("Finish All")
                    .font(.headline)
                    .foregroundColor(.white)
                    .frame(maxWidth: .infinity)
                    .padding(12)
                    .background(Color.blue)
                    .cornerRadius(10)
            }
            
            // List of tasks
            List {
                ForEach($todoItems) { $item in
                    HStack {
                        Text(item.task)
                            .strikethrough(item.isCompleted, color: .gray)
                            .foregroundColor(item.isCompleted ? .gray : .primary)
                            
                        
                        Spacer()
                        
                        Toggle("", isOn: $item.isCompleted)
//                            .labelsHidden()
                    }
                }
            }
            .listStyle(PlainListStyle())
        }
        .navigationTitle("Todo List")
    
        .padding()
            
}
       
    private func addTask() {
           guard !newTask.isEmpty else { return }
           let newItem = TodoItem(task: newTask, isCompleted: false)
           todoItems.append(newItem)
           newTask = ""
       }
       
    private func selectAllTasks() {
           for index in todoItems.indices {
               todoItems[index].isCompleted = true
           }
    }
    
//    private func countCompletedTasks(int isDone, int notDone) {
//        ForEach($todoItems) { $item in
//            if(item.isCompleted){
//                isDone += 1
//            }else{
//                notDone += 1
//            }
//        }
//        
//    }
   
}



#Preview {
    ContentView()
}
