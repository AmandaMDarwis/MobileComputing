//
//  ContentView.swift
//  THW2_0706022310051_AmandaMD
//
//  Created by Timothy on 21/09/25.
//

import SwiftUI

struct TodoItem: Identifiable {
    let id = UUID()
    var task: String
    var isCompleted: Bool
}

struct ContentView: View {
    @State private var newTask = ""
    @State private var todoItems: [TodoItem] = []
    
    var body: some View {
        VStack {
            Text("Welcome !")
                .font(.largeTitle).fontWeight(.bold)
//                .foregroundColor(.blue)
//                .shadow(color: .gray.opacity(0.3), radius: 5, x: 0, y: 5)
                .foregroundStyle(LinearGradient(
                    colors: [.blue, .purple],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing)
                    )
               
            Text("Your To-Do List :")
                .font(.title2)
                .padding(.bottom, 30)
                // .font(.system(size: 34, weight: .bold, design: .rounded))
            
            HStack(){
//                if !todoItems.isEmpty {
                    Button(action: selectAllTasks) {
                        Text("Select All")
                            .font(.headline)
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.blue)
                            .cornerRadius(10)
                    }
//                    .padding(.horizontal)
//                }
                Button(action: addTask) {
                    Image(systemName: "plus.circle.fill")
                        .foregroundColor(.blue)
                }
                
               
            }
            
            
        
                TextField("Enter your assignments", text: $newTask)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                
                
                .disabled(newTask.isEmpty)
//            .padding(.horizontal)
            
           
            
            // List of tasks
            List {
                ForEach($todoItems) { $item in
                    HStack {
                        Text(item.task)
                            .strikethrough(item.isCompleted, color: .gray)
                            .foregroundColor(item.isCompleted ? .gray : .primary)
                        
                        Spacer()
                        
                        Toggle("", isOn: $item.isCompleted)
//                            .labelsHidden()
                    }
                }
            }
            .listStyle(PlainListStyle())
        }
        .navigationTitle("Todo List")
    
        .padding()
            
}
       
    private func addTask() {
           guard !newTask.isEmpty else { return }
           let newItem = TodoItem(task: newTask, isCompleted: false)
           todoItems.append(newItem)
           newTask = ""
       }
       
       private func selectAllTasks() {
           for index in todoItems.indices {
               todoItems[index].isCompleted = true
           }
       }
   
}



#Preview {
    ContentView()
}
